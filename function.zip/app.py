def lambda_handler(event, context):

    return {
        "statusCode": 200,
        "miniatura_key": "miniatures/dummy-miniatura.jpg",
        "body": {
            "mensaje": "Lambda funcionando"
        }
    }
